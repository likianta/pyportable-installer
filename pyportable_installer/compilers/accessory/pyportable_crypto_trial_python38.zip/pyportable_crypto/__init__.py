from .encrypt import encrypt_data, encrypt_file
from .inject import inject

__version__ = "0.1.1-trial"
